import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Save, X, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { User as SupabaseUser, Session } from '@supabase/supabase-js';

interface ProfileData {
  display_name: string;
  age: string;
  bio: string;
  seeking_type: 'romantic' | 'business' | 'study' | 'project' | '';
  location: string;
  interests: string[];
}

export default function ProfileSetup() {
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(false);
  const [newInterest, setNewInterest] = useState("");
  const [profileData, setProfileData] = useState<ProfileData>({
    display_name: '',
    age: '',
    bio: '',
    seeking_type: '',
    location: '',
    interests: [],
  });
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (!session?.user) {
          navigate('/auth');
        }
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session?.user) {
        navigate('/auth');
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching profile:', error);
    } else if (data) {
      setProfileData({
        display_name: data.display_name || '',
        age: data.age?.toString() || '',
        bio: data.bio || '',
        seeking_type: data.seeking_type as 'romantic' | 'business' | 'study' | 'project' || '',
        location: data.location || '',
        interests: data.interests || [],
      });
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    
    if (!profileData.display_name || !profileData.seeking_type) {
      toast({
        title: "Missing required fields",
        description: "Please fill in your name and what type of connection you're seeking.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    const profilePayload = {
      user_id: user.id,
      display_name: profileData.display_name,
      age: profileData.age ? parseInt(profileData.age) : null,
      bio: profileData.bio || null,
      seeking_type: profileData.seeking_type,
      location: profileData.location || null,
      interests: profileData.interests.length > 0 ? profileData.interests : null,
    };

    const { error } = await supabase
      .from('profiles')
      .upsert(profilePayload, { onConflict: 'user_id' });
    
    if (error) {
      toast({
        title: "Error saving profile",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Profile saved!",
        description: "Your profile has been updated successfully.",
      });
      navigate('/dashboard');
    }
    
    setLoading(false);
  };

  const addInterest = () => {
    if (newInterest.trim() && !profileData.interests.includes(newInterest.trim())) {
      setProfileData(prev => ({
        ...prev,
        interests: [...prev.interests, newInterest.trim()]
      }));
      setNewInterest("");
    }
  };

  const removeInterest = (interest: string) => {
    setProfileData(prev => ({
      ...prev,
      interests: prev.interests.filter(i => i !== interest)
    }));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addInterest();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/20 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <div className="text-center">
            <h1 className="text-3xl font-bold bg-gradient-hero bg-clip-text text-transparent mb-2">
              Set Up Your Profile
            </h1>
            <p className="text-muted-foreground">
              Tell others about yourself and what you're looking for
            </p>
          </div>
        </div>

        <Card className="bg-gradient-card shadow-medium">
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>
              Create a compelling profile to attract the right connections
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="display_name">Display Name *</Label>
                <Input
                  id="display_name"
                  placeholder="How should others see you?"
                  value={profileData.display_name}
                  onChange={(e) => setProfileData(prev => ({ ...prev, display_name: e.target.value }))}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  type="number"
                  placeholder="Your age"
                  value={profileData.age}
                  onChange={(e) => setProfileData(prev => ({ ...prev, age: e.target.value }))}
                />
              </div>
            </div>

            {/* Connection Type */}
            <div className="space-y-2">
              <Label htmlFor="seeking_type">What are you looking for? *</Label>
              <Select
                value={profileData.seeking_type}
                onValueChange={(value: 'romantic' | 'business' | 'study' | 'project') => 
                  setProfileData(prev => ({ ...prev, seeking_type: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select connection type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="romantic">Romantic Partner</SelectItem>
                  <SelectItem value="business">Business Partner</SelectItem>
                  <SelectItem value="study">Study Buddy</SelectItem>
                  <SelectItem value="project">Project Collaborator</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="City, Country"
                value={profileData.location}
                onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
              />
            </div>

            {/* Bio */}
            <div className="space-y-2">
              <Label htmlFor="bio">About You</Label>
              <Textarea
                id="bio"
                placeholder="Tell others about yourself, your goals, and what makes you unique..."
                value={profileData.bio}
                onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                rows={4}
              />
            </div>

            {/* Interests */}
            <div className="space-y-4">
              <Label>Interests & Skills</Label>
              
              <div className="flex gap-2">
                <Input
                  placeholder="Add an interest or skill"
                  value={newInterest}
                  onChange={(e) => setNewInterest(e.target.value)}
                  onKeyPress={handleKeyPress}
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  size="icon"
                  onClick={addInterest}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              {profileData.interests.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {profileData.interests.map((interest, index) => (
                    <Badge key={index} variant="secondary" className="gap-1">
                      {interest}
                      <button
                        onClick={() => removeInterest(interest)}
                        className="hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Save Button */}
            <div className="flex justify-end pt-4">
              <Button 
                onClick={handleSaveProfile}
                variant="hero"
                size="lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Profile
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
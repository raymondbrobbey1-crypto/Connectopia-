import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ProfileCard } from "@/components/ProfileCard";
import { ConnectionTypeFilter } from "@/components/ConnectionTypeFilter";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, User, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { User as SupabaseUser, Session } from '@supabase/supabase-js';

type ConnectionType = 'all' | 'romantic' | 'business' | 'study' | 'project';

interface Profile {
  id: string;
  display_name: string;
  age?: number;
  bio?: string;
  interests?: string[];
  seeking_type: 'romantic' | 'business' | 'study' | 'project';
  location?: string;
  avatar_url?: string;
  user_id: string;
}

export default function Dashboard() {
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [filteredProfiles, setFilteredProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<ConnectionType>('all');
  const [userProfile, setUserProfile] = useState<Profile | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (!session?.user) {
          navigate('/auth');
        }
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session?.user) {
        navigate('/auth');
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (user) {
      fetchUserProfile();
      fetchProfiles();
    }
  }, [user]);

  useEffect(() => {
    let filtered = profiles.filter(profile => profile.user_id !== user?.id);
    
    if (activeFilter !== 'all') {
      filtered = filtered.filter(profile => profile.seeking_type === activeFilter);
    }
    
    if (searchQuery) {
      filtered = filtered.filter(profile => 
        profile.display_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        profile.interests?.some(interest => 
          interest.toLowerCase().includes(searchQuery.toLowerCase())
        )
      );
    }
    
    setFilteredProfiles(filtered);
  }, [profiles, activeFilter, searchQuery, user?.id]);

  const fetchUserProfile = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching user profile:', error);
    } else {
      setUserProfile(data as Profile);
      if (!data) {
        navigate('/profile-setup');
      }
    }
  };

  const fetchProfiles = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      toast({
        title: "Error loading profiles",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setProfiles((data as Profile[]) || []);
    }
    setLoading(false);
  };

  const handleConnect = async (profileId: string) => {
    if (!user) return;
    
    const { error } = await supabase
      .from('connections')
      .insert({
        requester_id: user.id,
        receiver_id: profiles.find(p => p.id === profileId)?.user_id,
      });
    
    if (error) {
      if (error.message.includes('duplicate key value')) {
        toast({
          title: "Already connected",
          description: "You've already sent a connection request to this person.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Connection failed",
          description: error.message,
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Connection request sent!",
        description: "We'll notify you when they respond.",
      });
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  if (loading && user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your connections...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold bg-gradient-hero bg-clip-text text-transparent">
                Connectopia
              </h1>
              {userProfile && (
                <span className="text-muted-foreground">
                  Welcome back, {userProfile.display_name}!
                </span>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate('/profile-setup')}
              >
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleSignOut}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search by name or interests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <ConnectionTypeFilter
            activeType={activeFilter}
            onTypeChange={setActiveFilter}
          />
        </div>

        {/* Profiles Grid */}
        {filteredProfiles.length === 0 ? (
          <div className="text-center py-12">
            <div className="mb-4">
              {profiles.length === 0 ? (
                <p className="text-muted-foreground text-lg">
                  No profiles yet. Be the first to join!
                </p>
              ) : (
                <p className="text-muted-foreground text-lg">
                  No profiles match your current filters.
                </p>
              )}
            </div>
            <Button 
              variant="hero"
              onClick={() => navigate('/profile-setup')}
            >
              <Plus className="h-4 w-4 mr-2" />
              {!userProfile ? 'Create Your Profile' : 'Edit Your Profile'}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProfiles.map((profile) => (
              <ProfileCard
                key={profile.id}
                profile={profile}
                onConnect={handleConnect}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
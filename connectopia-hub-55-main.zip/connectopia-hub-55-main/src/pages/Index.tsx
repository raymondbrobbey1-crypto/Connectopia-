import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Briefcase, BookOpen, Code, Users, ArrowRight, Sparkles, Shield, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { User as SupabaseUser, Session } from '@supabase/supabase-js';
import { cn } from "@/lib/utils";
import heroImage from "@/assets/hero-connections.jpg";

const connectionTypes = [
  {
    type: 'romantic',
    icon: Heart,
    title: 'Romantic Partners',
    description: 'Find meaningful relationships and love connections',
    color: 'text-romantic border-romantic',
    bgColor: 'bg-romantic/10'
  },
  {
    type: 'business',
    icon: Briefcase,
    title: 'Business Partners',
    description: 'Connect with entrepreneurs and collaborators',
    color: 'text-business border-business',
    bgColor: 'bg-business/10'
  },
  {
    type: 'study',
    icon: BookOpen,
    title: 'Study Buddies',
    description: 'Learn together and achieve academic goals',
    color: 'text-study border-study',
    bgColor: 'bg-study/10'
  },
  {
    type: 'project',
    icon: Code,
    title: 'Project Collaborators',
    description: 'Build amazing things with like-minded creators',
    color: 'text-project border-project',
    bgColor: 'bg-project/10'
  }
];

const features = [
  {
    icon: Users,
    title: 'Smart Matching',
    description: 'Advanced algorithms connect you with compatible people based on your interests and goals.'
  },
  {
    icon: Shield,
    title: 'Safe & Secure',
    description: 'Verified profiles and robust privacy controls keep your information protected.'
  },
  {
    icon: Zap,
    title: 'Instant Connections',
    description: 'Start meaningful conversations and build relationships that matter.'
  }
];

export default function Index() {
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleGetStarted = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      navigate('/auth');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-primary rounded-lg">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-hero bg-clip-text text-transparent">
                Connectopia
              </h1>
            </div>
            
            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <span className="text-muted-foreground">Welcome back!</span>
                  <Button onClick={() => navigate('/dashboard')} variant="hero">
                    Dashboard
                  </Button>
                </>
              ) : (
                <>
                  <Button onClick={() => navigate('/auth')} variant="ghost">
                    Sign In
                  </Button>
                  <Button onClick={() => navigate('/auth')} variant="hero">
                    Get Started
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={heroImage} 
            alt="Connection network visualization" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-hero/90"></div>
        </div>
        
        <div className="relative container mx-auto px-4 py-24 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-2 mb-6">
              <Sparkles className="h-8 w-8 text-white animate-pulse" />
              <Badge variant="outline" className="text-white border-white/30 bg-white/10">
                The Future of Connections
              </Badge>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Find Your Perfect
              <br />
              <span className="bg-gradient-to-r from-accent to-white bg-clip-text text-transparent">
                Connection
              </span>
            </h1>
            
            <p className="text-xl text-white/80 mb-8 leading-relaxed max-w-2xl mx-auto">
              Whether you're seeking romance, business partnerships, study companions, or project collaborators — 
              Connectopia brings together like-minded people ready to build meaningful relationships.
            </p>
            
            <div className="space-y-4 md:space-y-0 md:space-x-4 md:flex md:justify-center">
              <Button 
                onClick={handleGetStarted}
                variant="accent"
                size="lg"
                className="text-lg px-8 py-4 shadow-glow hover:scale-105"
              >
                Start Connecting
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Connection Types */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Kind of Connection Are You Looking For?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Our platform supports all types of meaningful connections. Choose your path and find your people.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {connectionTypes.map((type, index) => {
              const Icon = type.icon;
              return (
                <Card key={index} className={cn(
                  "relative overflow-hidden bg-gradient-card hover:shadow-medium transition-smooth hover:scale-105 cursor-pointer group",
                  type.bgColor
                )}>
                  <CardContent className="p-6 text-center">
                    <div className={cn(
                      "w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-smooth group-hover:scale-110",
                      type.color.replace('text-', 'bg-').replace('border-', 'bg-') + '/20'
                    )}>
                      <Icon className={cn("h-8 w-8", type.color)} />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{type.title}</h3>
                    <p className="text-muted-foreground text-sm">{type.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why Choose Connectopia?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              We've built the most comprehensive platform for finding meaningful connections across all aspects of life.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6 shadow-glow">
                    <Icon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="font-semibold text-xl mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-hero">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Make Your First Connection?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Join thousands of people who have already found their perfect matches, 
            collaborators, and companions on Connectopia.
          </p>
          
          <Button 
            onClick={handleGetStarted}
            variant="accent"
            size="lg"
            className="text-lg px-8 py-4 shadow-glow hover:scale-105"
          >
            {user ? 'Go to Dashboard' : 'Sign Up Now'}
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card/50 py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="h-5 w-5 text-primary" />
            <span className="font-semibold">Connectopia</span>
          </div>
          <p className="text-muted-foreground text-sm">
            Built with ❤️ for meaningful connections
          </p>
        </div>
      </footer>
    </div>
  );
}

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Heart, Briefcase, BookOpen, Code, MapPin, MessageCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface Profile {
  id: string;
  display_name: string;
  age?: number;
  bio?: string;
  interests?: string[];
  seeking_type: 'romantic' | 'business' | 'study' | 'project';
  location?: string;
  avatar_url?: string;
}

interface ProfileCardProps {
  profile: Profile;
  onConnect: (profileId: string) => void;
  className?: string;
}

const connectionIcons = {
  romantic: Heart,
  business: Briefcase,
  study: BookOpen,
  project: Code,
};

const connectionColors = {
  romantic: 'text-romantic border-romantic',
  business: 'text-business border-business',
  study: 'text-study border-study',
  project: 'text-project border-project',
};

export function ProfileCard({ profile, onConnect, className }: ProfileCardProps) {
  const Icon = connectionIcons[profile.seeking_type];
  const colorClass = connectionColors[profile.seeking_type];

  return (
    <Card className={cn(
      "overflow-hidden bg-gradient-card hover:shadow-medium transition-smooth hover:scale-[1.02] cursor-pointer",
      className
    )}>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16 ring-2 ring-primary/20">
            <AvatarImage src={profile.avatar_url} alt={profile.display_name} />
            <AvatarFallback className="bg-gradient-primary text-primary-foreground text-lg font-semibold">
              {profile.display_name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-lg text-foreground truncate">
                {profile.display_name}
              </h3>
              {profile.age && (
                <span className="text-muted-foreground text-sm">• {profile.age}</span>
              )}
            </div>
            
            <div className="flex items-center gap-1 mb-3">
              <Icon className={cn("h-4 w-4", colorClass)} />
              <Badge variant="outline" className={cn("capitalize", colorClass)}>
                {profile.seeking_type}
              </Badge>
            </div>

            {profile.location && (
              <div className="flex items-center gap-1 text-muted-foreground text-sm mb-3">
                <MapPin className="h-3 w-3" />
                <span>{profile.location}</span>
              </div>
            )}

            {profile.bio && (
              <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                {profile.bio}
              </p>
            )}

            {profile.interests && profile.interests.length > 0 && (
              <div className="flex flex-wrap gap-1 mb-4">
                {profile.interests.slice(0, 3).map((interest, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {interest}
                  </Badge>
                ))}
                {profile.interests.length > 3 && (
                  <Badge variant="secondary" className="text-xs">
                    +{profile.interests.length - 3}
                  </Badge>
                )}
              </div>
            )}

            <Button 
              onClick={() => onConnect(profile.id)}
              variant="hero"
              size="sm"
              className="w-full"
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Connect
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
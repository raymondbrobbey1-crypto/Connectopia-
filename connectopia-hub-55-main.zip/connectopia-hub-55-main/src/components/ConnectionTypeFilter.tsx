import { Button } from "@/components/ui/button";
import { Heart, Briefcase, BookOpen, Code, Users } from "lucide-react";
import { cn } from "@/lib/utils";

type ConnectionType = 'all' | 'romantic' | 'business' | 'study' | 'project';

interface ConnectionTypeFilterProps {
  activeType: ConnectionType;
  onTypeChange: (type: ConnectionType) => void;
  className?: string;
}

const connectionTypes = [
  { type: 'all' as const, label: 'All', icon: Users, color: 'text-foreground' },
  { type: 'romantic' as const, label: 'Romantic', icon: Heart, color: 'text-romantic' },
  { type: 'business' as const, label: 'Business', icon: Briefcase, color: 'text-business' },
  { type: 'study' as const, label: 'Study', icon: BookOpen, color: 'text-study' },
  { type: 'project' as const, label: 'Project', icon: Code, color: 'text-project' },
];

export function ConnectionTypeFilter({ activeType, onTypeChange, className }: ConnectionTypeFilterProps) {
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {connectionTypes.map(({ type, label, icon: Icon, color }) => {
        const isActive = activeType === type;
        return (
          <Button
            key={type}
            variant={isActive ? "default" : "outline"}
            size="sm"
            onClick={() => onTypeChange(type)}
            className={cn(
              "transition-smooth",
              isActive 
                ? "bg-gradient-primary text-primary-foreground shadow-soft" 
                : "hover:shadow-soft",
              !isActive && color
            )}
          >
            <Icon className="h-4 w-4 mr-2" />
            {label}
          </Button>
        );
      })}
    </div>
  );
}